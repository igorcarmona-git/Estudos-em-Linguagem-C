// 3) Faça uma função recursiva que permita inverter um número inteiro N. Ex: 123 - 321

// Não consegui fazer.